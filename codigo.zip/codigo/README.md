# Código do Projeto

```txt
├── src
│   ├── pages
│   │   ├── *.html
│   ├── js
│   │   ├── *.js
│   ├── css
│   │   ├── *.css
│   ├── img
│   │   ├── *.png
│   │   ├── *.jpeg
│   │   ├── *.webp
│   │   ├── *.ico
├──  index.html
├──  README.md
```